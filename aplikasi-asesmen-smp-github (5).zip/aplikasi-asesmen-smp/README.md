# EduAssess — Aplikasi Asesmen Digital SMP/MTs

Aplikasi web statis untuk asesmen siswa dengan:
- Login siswa menggunakan nama dan kelas
- Login guru demo menggunakan PIN
- Paket soal LOTS dan HOTS
- Penilaian otomatis
- Rekap nilai guru
- Ekspor rekap ke CSV
- Tampilan responsif untuk HP dan komputer

## Menjalankan di komputer
1. Ekstrak ZIP.
2. Buka folder `aplikasi-asesmen-smp`.
3. Klik dua kali `index.html` atau buka dengan browser.

## Memasang di GitHub Pages
1. Login ke https://github.com/
2. Buat repository baru, misalnya `aplikasi-asesmen-smp`.
3. Pilih Public (atau sesuai kebutuhan akun), lalu Create repository.
4. Klik **Add file → Upload files**.
5. Unggah `index.html` dari folder ini, lalu klik **Commit changes**.
6. Buka **Settings → Pages**.
7. Pada **Build and deployment**, pilih **Deploy from a branch**.
8. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
9. Tunggu proses publikasi. URL biasanya:
   `https://NAMA-USERNAME.github.io/aplikasi-asesmen-smp/`

## Mengganti PIN guru
Buka `index.html`, cari:
`const TEACHER_PIN = "246810";`
Ganti angka tersebut sebelum mengunggah.

## Mengubah soal
Di dalam `index.html`, cari bagian `const questionBank`.
- `LOTS` berisi soal pemahaman dasar.
- `HOTS` berisi soal berpikir tingkat tinggi.
Setiap soal memiliki `topic`, `q` (pertanyaan), `a` (4 pilihan), `c` (indeks jawaban benar dimulai dari 0), dan `why` (alasan jawaban).

Contoh:
`{topic:"IPA • Materi",q:"Pertanyaan ...",a:["Pilihan A","Pilihan B","Pilihan C","Pilihan D"],c:2,why:"Penjelasan ..."}`

## Batasan penting versi awal
Versi ini memakai `localStorage` pada browser. Artinya:
- Nilai hanya tersimpan pada browser/perangkat yang mengerjakan.
- Dashboard guru hanya membaca hasil yang tersimpan pada browser/perangkat yang sama.
- Hasil siswa dari HP yang berbeda tidak otomatis terkumpul di satu dashboard.
- Login guru dengan PIN di JavaScript hanya untuk demo, bukan keamanan sungguhan.
- Jangan memasukkan data pribadi sensitif siswa.

Untuk penggunaan sekolah sungguhan dengan akun aman dan rekap lintas perangkat, hubungkan aplikasi ke backend/database (misalnya Supabase atau Firebase) dengan autentikasi dan aturan akses yang benar.
